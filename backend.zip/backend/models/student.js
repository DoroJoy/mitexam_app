const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let studentSchema = new Schema({
  fullname: {
    type: String
  },
  email: {
    type: String
  },
  contact: {
    type: String
  }
  ,
  emergencycontact: {
    type: String
  },
  shirtsize: {
    type: String
  }
  ,
  address: {
    type: String
  }
  ,
  comment: {
    type: String
  }
}, {
    collection: 'students'
  })

module.exports = mongoose.model('Student', studentSchema)